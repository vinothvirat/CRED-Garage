"use client"

import type React from "react"

import { Sidebar } from "@/components/dashboard/sidebar"
import { Header } from "@/components/dashboard/header"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="min-h-screen bg-background">
      <div className="flex h-screen">
        {/* Fixed Sidebar */}
        <div className="fixed left-0 top-0 h-full z-30">
          <Sidebar />
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col ml-64">
          {/* Fixed Header */}
          <div className="fixed top-0 right-0 left-64 z-20">
            <Header />
          </div>

          {/* Scrollable Content */}
          <main className="flex-1 pt-20 p-6 overflow-auto mt-8">{children}</main>
        </div>
      </div>
    </div>
  )
}
