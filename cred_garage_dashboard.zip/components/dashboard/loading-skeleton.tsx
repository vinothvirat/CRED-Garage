"use client"

import { motion } from "framer-motion"
import { Skeleton } from "@/components/ui/skeleton"
import { Card, CardContent, CardHeader } from "@/components/ui/card"

export function LoadingSkeleton() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="flex">
        {/* Sidebar Skeleton */}
        <div className="w-64 bg-black/20 backdrop-blur-xl border-r border-white/10 p-6 hidden md:block">
          <div className="mb-8">
            <Skeleton className="h-8 w-20 bg-white/10" />
            <Skeleton className="h-4 w-16 mt-2 bg-white/10" />
          </div>
          <div className="space-y-2">
            {Array.from({ length: 7 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full bg-white/10" />
            ))}
          </div>
        </div>

        <div className="flex-1 flex flex-col">
          {/* Header Skeleton */}
          <div className="bg-black/20 backdrop-blur-xl border-b border-white/10 p-6">
            <div className="flex items-center justify-between">
              <Skeleton className="h-10 w-64 bg-white/10" />
              <div className="flex items-center space-x-4">
                <Skeleton className="h-10 w-10 rounded-full bg-white/10" />
                <Skeleton className="h-10 w-10 rounded-full bg-white/10" />
                <Skeleton className="h-10 w-10 rounded-full bg-white/10" />
              </div>
            </div>
          </div>

          {/* Main Content Skeleton */}
          <main className="flex-1 p-6 space-y-6">
            {/* User Profile Skeleton */}
            <Card className="bg-white/5 border-white/10">
              <CardContent className="p-6">
                <div className="flex items-center space-x-4">
                  <Skeleton className="w-16 h-16 rounded-full bg-white/10" />
                  <div className="space-y-2">
                    <Skeleton className="h-6 w-32 bg-white/10" />
                    <Skeleton className="h-4 w-24 bg-white/10" />
                    <div className="flex space-x-2">
                      <Skeleton className="h-6 w-16 bg-white/10" />
                      <Skeleton className="h-6 w-12 bg-white/10" />
                    </div>
                  </div>
                </div>
                <Skeleton className="h-2 w-full mt-6 bg-white/10" />
              </CardContent>
            </Card>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Benefits Section Skeleton */}
              <div className="lg:col-span-2 space-y-4">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-8 w-32 bg-white/10" />
                  <Skeleton className="h-10 w-20 bg-white/10" />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Array.from({ length: 6 }).map((_, i) => (
                    <Card key={i} className="bg-white/5 border-white/10">
                      <CardHeader>
                        <div className="flex items-start justify-between">
                          <Skeleton className="w-12 h-12 rounded-lg bg-white/10" />
                          <Skeleton className="w-16 h-6 bg-white/10" />
                        </div>
                        <Skeleton className="h-6 w-32 bg-white/10" />
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Skeleton className="h-4 w-full bg-white/10" />
                        <div className="flex items-center justify-between">
                          <Skeleton className="h-6 w-20 bg-white/10" />
                          <Skeleton className="h-8 w-16 bg-white/10" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Reward Progress Skeleton */}
              <div className="space-y-6">
                <Card className="bg-white/5 border-white/10">
                  <CardHeader>
                    <Skeleton className="h-6 w-32 bg-white/10" />
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="text-center">
                      <Skeleton className="w-32 h-32 rounded-full mx-auto bg-white/10" />
                      <Skeleton className="h-4 w-full mt-4 bg-white/10" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <Skeleton className="h-16 bg-white/10" />
                      <Skeleton className="h-16 bg-white/10" />
                    </div>
                    <Skeleton className="h-10 w-full bg-white/10" />
                  </CardContent>
                </Card>
              </div>
            </div>
          </main>
        </div>
      </div>

      {/* Loading Animation */}
      <motion.div
        className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm z-50"
        initial={{ opacity: 1 }}
        animate={{ opacity: 0 }}
        transition={{ duration: 0.5, delay: 1.5 }}
        style={{ pointerEvents: "none" }}
      >
        <div className="text-center">
          <motion.div
            className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full mx-auto mb-4"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
          />
          <motion.p
            className="text-white text-lg"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            Loading your dashboard...
          </motion.p>
        </div>
      </motion.div>
    </div>
  )
}
