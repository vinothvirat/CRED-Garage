"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Crown, Star, TrendingUp } from "lucide-react"

export function UserProfile() {
  const userLevel = 7
  const currentXP = 2450
  const nextLevelXP = 3000
  const progressPercentage = (currentXP / nextLevelXP) * 100

  return (
    <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.5 }}>
      <Card className="bg-gradient-to-r from-purple-900/50 to-pink-900/50 border-white/20 backdrop-blur-xl">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Avatar className="w-16 h-16 border-2 border-purple-400">
                  <AvatarImage src="/placeholder-user.jpg" />
                  {/* <AvatarFallback>JD</AvatarFallback> */}
                </Avatar>
                <div className="absolute -bottom-1 -right-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full p-1">
                  <Crown className="w-4 h-4 text-white" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">vinothkumar</h2>
                <p className="text-gray-400">Premium Member</p>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge variant="secondary" className="bg-purple-600/50 text-purple-200">
                    Level {userLevel}
                  </Badge>
                  <Badge variant="secondary" className="bg-yellow-600/50 text-yellow-200">
                    <Star className="w-3 h-3 mr-1" />
                    Elite
                  </Badge>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="flex items-center text-green-400 mb-1">
                <TrendingUp className="w-4 h-4 mr-1" />
                <span className="text-sm">+125 XP today</span>
              </div>
              <p className="text-gray-400 text-sm">Next level in {nextLevelXP - currentXP} XP</p>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-400">Level Progress</span>
              <span className="text-white">
                {currentXP} / {nextLevelXP} XP
              </span>
            </div>
            <Progress value={progressPercentage} className="h-2 bg-gray-800">
              <div
                className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all duration-500"
                style={{ width: `${progressPercentage}%` }}
              />
            </Progress>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
