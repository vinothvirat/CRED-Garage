"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Button } from "@/components/ui/button"
import { Coins, Gift, TrendingUp, Target, Zap } from "lucide-react"

export function RewardProgress() {
  const totalPoints = 12450
  const monthlyTarget = 15000
  const progressPercentage = (totalPoints / monthlyTarget) * 100
  const pointsToTarget = monthlyTarget - totalPoints

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-yellow-900/50 to-orange-900/50 border-white/20 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-white">
            <Coins className="w-5 h-5 mr-2 text-yellow-400" />
            Reward Points
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="relative w-32 h-32 mx-auto mb-4"
            >
              <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="40" stroke="rgba(255,255,255,0.1)" strokeWidth="8" fill="none" />
                <motion.circle
                  cx="50"
                  cy="50"
                  r="40"
                  stroke="url(#gradient)"
                  strokeWidth="8"
                  fill="none"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 40}`}
                  initial={{ strokeDashoffset: 2 * Math.PI * 40 }}
                  animate={{ strokeDashoffset: 2 * Math.PI * 40 * (1 - progressPercentage / 100) }}
                  transition={{ duration: 1, delay: 0.5 }}
                />
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#fbbf24" />
                    <stop offset="100%" stopColor="#f59e0b" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center">
                  <div className="text-2xl font-bold text-white">{totalPoints.toLocaleString()}</div>
                  <div className="text-xs text-gray-400">Points</div>
                </div>
              </div>
            </motion.div>

            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Monthly Target</span>
                <span className="text-white">{progressPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={progressPercentage} className="h-2 bg-gray-800">
                <div
                  className="h-full bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full transition-all duration-500"
                  style={{ width: `${progressPercentage}%` }}
                />
              </Progress>
              <p className="text-xs text-gray-400">{pointsToTarget.toLocaleString()} points to reach target</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-white/5 rounded-lg p-3 text-center">
              <TrendingUp className="w-5 h-5 text-green-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">+245</div>
              <div className="text-xs text-gray-400">This Week</div>
            </div>
            <div className="bg-white/5 rounded-lg p-3 text-center">
              <Target className="w-5 h-5 text-blue-400 mx-auto mb-1" />
              <div className="text-lg font-bold text-white">83%</div>
              <div className="text-xs text-gray-400">Goal Progress</div>
            </div>
          </div>

          <Button className="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-700 hover:to-orange-700">
            <Gift className="w-4 h-4 mr-2" />
            Redeem Points
          </Button>
        </CardContent>
      </Card>

      <Card className="bg-black/30 border-white/10 backdrop-blur-xl">
        <CardHeader>
          <CardTitle className="flex items-center text-white text-sm">
            <Zap className="w-4 h-4 mr-2 text-yellow-400" />
            Quick Actions
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start border-white/20 text-white hover:bg-white/10"
          >
            <Gift className="w-4 h-4 mr-2" />
            View Rewards Catalog
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start border-white/20 text-white hover:bg-white/10"
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Points History
          </Button>
          <Button
            variant="outline"
            size="sm"
            className="w-full justify-start border-white/20 text-white hover:bg-white/10"
          >
            <Target className="w-4 h-4 mr-2" />
            Set Monthly Goal
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
