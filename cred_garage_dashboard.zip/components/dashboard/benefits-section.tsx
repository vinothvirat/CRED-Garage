"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ShoppingBag, Coffee, Car, Plane, Utensils, Film, Sparkles, Clock } from "lucide-react"

const benefits = [
  {
    id: 1,
    title: "Shopping Cashback",
    description: "Get up to 10% cashback on all online purchases",
    icon: ShoppingBag,
    discount: "10% OFF",
    category: "Shopping",
    isNew: true,
    color: "from-blue-500 to-cyan-500",
  },
  {
    id: 2,
    title: "Coffee Rewards",
    description: "Free coffee every 10th purchase at partner cafes",
    icon: Coffee,
    discount: "Buy 9 Get 1 Free",
    category: "Food & Beverage",
    isNew: false,
    color: "from-amber-500 to-orange-500",
  },
  {
    id: 3,
    title: "Fuel Savings",
    description: "Save ₹5 per litre on fuel at select stations",
    icon: Car,
    discount: "₹5/L OFF",
    category: "Fuel",
    isNew: false,
    color: "from-green-500 to-emerald-500",
  },
  {
    id: 4,
    title: "Travel Deals",
    description: "Exclusive discounts on flights and hotels",
    icon: Plane,
    discount: "25% OFF",
    category: "Travel",
    isNew: true,
    color: "from-purple-500 to-pink-500",
  },
  {
    id: 5,
    title: "Dining Offers",
    description: "Special prices at premium restaurants",
    icon: Utensils,
    discount: "20% OFF",
    category: "Dining",
    isNew: false,
    color: "from-red-500 to-rose-500",
  },
  {
    id: 6,
    title: "Movie Tickets",
    description: "Discounted movie tickets every weekend",
    icon: Film,
    discount: "Buy 1 Get 1",
    category: "Entertainment",
    isNew: false,
    color: "from-indigo-500 to-purple-500",
  },
]

interface BenefitsSectionProps {
  showAll?: boolean
}

export function BenefitsSection({ showAll = false }: BenefitsSectionProps) {
  const displayBenefits = showAll ? benefits : benefits.slice(0, 6)

  return (
    <div className="space-y-6">
      {!showAll && (
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold text-foreground">Your Benefits</h2>
          <Button variant="outline">View All</Button>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {displayBenefits.map((benefit, index) => (
          <motion.div
            key={benefit.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            whileHover={{ scale: 1.02 }}
            className="group"
          >
            <Card className="bg-card border-border hover:shadow-lg transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className={`p-3 rounded-lg bg-gradient-to-r ${benefit.color} bg-opacity-20`}>
                    <benefit.icon className="w-6 h-6 text-foreground" />
                  </div>
                  <div className="flex flex-col items-end space-y-1">
                    {benefit.isNew && (
                      <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs">
                        <Sparkles className="w-3 h-3 mr-1" />
                        NEW
                      </Badge>
                    )}
                    <Badge variant="secondary" className="text-xs">
                      {benefit.category}
                    </Badge>
                  </div>
                </div>
                <CardTitle className="text-foreground text-lg">{benefit.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-muted-foreground text-sm">{benefit.description}</p>
                <div className="flex items-center justify-between">
                  <div className={`px-3 py-1 rounded-full bg-gradient-to-r ${benefit.color} bg-opacity-20`}>
                    <span className="text-foreground font-semibold text-sm">{benefit.discount}</span>
                  </div>
                  <Button
                    size="sm"
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                  >
                    Claim
                  </Button>
                </div>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="w-3 h-3 mr-1" />
                  <span>Valid till Dec 31, 2024</span>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    </div>
  )
}
