"use client"

import { motion } from "framer-motion"
import { Home, CreditCard, Gift, Trophy, Settings, HelpCircle, Wallet } from "lucide-react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"

const sidebarItems = [
  { icon: Home, label: "Dashboard", href: "/" },
  { icon: CreditCard, label: "Cards", href: "/cards" },
  { icon: Gift, label: "Benefits", href: "/benefits" },
  { icon: Trophy, label: "Rewards", href: "/rewards" },
  { icon: Wallet, label: "Wallet", href: "/wallet" },
  // { icon: Settings, label: "Settings", href: "/settings" },
  // { icon: HelpCircle, label: "Help", href: "/help" },
]

export function Sidebar() {
  const pathname = usePathname()

  return (
    <motion.div
      initial={{ x: -100, opacity: 0 }}
      animate={{ x: 0, opacity: 1 }}
      transition={{ duration: 0.5 }}
      className="w-64 h-full bg-card border-r border-border p-6"
    >
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-foreground">CRED</h1>
        <p className="text-sm text-muted-foreground">Garage</p>
      </div>

      <nav className="space-y-2">
        {sidebarItems.map((item, index) => {
          const isActive = pathname === item.href
          return (
            <motion.div
              key={item.label}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Link
                href={item.href}
                className={cn(
                  "flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 group",
                  isActive
                    ? "bg-gradient-to-r from-purple-600 to-pink-600 text-white"
                    : "text-muted-foreground hover:text-foreground hover:bg-accent",
                )}
              >
                <item.icon className="w-5 h-5" />
                <span className="font-medium">{item.label}</span>
              </Link>
            </motion.div>
          )
        })}
      </nav>
    </motion.div>
  )
}
