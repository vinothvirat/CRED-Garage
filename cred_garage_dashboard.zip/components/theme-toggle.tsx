"use client"

import * as React from "react"
import { Moon, Sun } from "lucide-react"
import { useTheme } from "next-themes"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { cn } from "@/lib/utils"

export function ThemeToggle() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = React.useState(false)

  React.useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
<Button
  variant="ghost"
  size="icon"
  onClick={() => setTheme(theme === "light" ? "dark" : "light")}
  className={cn(
    "border rounded-md transition-colors",
    "bg-muted text-foreground hover:bg-muted/80 border-border"
  )}
>
  <motion.div
    initial={false}
    animate={{ rotate: theme === "light" ? 0 : 180 }}
    transition={{ duration: 0.3 }}
  >
    {theme === "light" ? (
      <Sun className="h-5 w-5 text-yellow-500" />
    ) : (
      <Moon className="h-5 w-5 text-blue-400" />
    )}
  </motion.div>
  <span className="sr-only">Toggle theme</span>
</Button>
  )
}
