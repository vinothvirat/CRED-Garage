"use client"

import { motion } from "framer-motion"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { RewardProgress } from "@/components/dashboard/reward-progress"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Trophy, Star, Gift } from "lucide-react"

export default function RewardsPage() {
  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <div>
          <h1 className="text-3xl font-bold text-foreground">Rewards Center</h1>
          <p className="text-muted-foreground">Track your points and redeem amazing rewards</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center text-sm">
                    <Trophy className="w-4 h-4 mr-2 text-yellow-500" />
                    Total Earned
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">24,580</div>
                  <p className="text-xs text-muted-foreground">Lifetime points</p>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center text-sm">
                    <Star className="w-4 h-4 mr-2 text-purple-500" />
                    This Month
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">1,245</div>
                  <p className="text-xs text-muted-foreground">Points earned</p>
                </CardContent>
              </Card>

              <Card className="bg-card border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="flex items-center text-sm">
                    <Gift className="w-4 h-4 mr-2 text-green-500" />
                    Redeemed
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">12,130</div>
                  <p className="text-xs text-muted-foreground">Points used</p>
                </CardContent>
              </Card>
            </div>
          </div>
          <div>
            <RewardProgress />
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  )
}
