"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { UserProfile } from "@/components/dashboard/user-profile"
import { BenefitsSection } from "@/components/dashboard/benefits-section"
import { RewardProgress } from "@/components/dashboard/reward-progress"
import { LoadingSkeleton } from "@/components/dashboard/loading-skeleton"

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false)
    }, 2000)

    return () => clearTimeout(timer)
  }, [])

  if (isLoading) {
    return <LoadingSkeleton />
  }

  return (
    <DashboardLayout>
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="space-y-6"
      >
        <UserProfile />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <BenefitsSection />
          </div>
          <div>
            <RewardProgress />
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  )
}
